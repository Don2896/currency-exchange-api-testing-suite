BASE_URL = "https://v6.exchangerate-api.com/v6/747fd5b9db11dbb758cbafbc/latest/USD"
PARAMS = {"base": "USD", "symbols": "GBP"}
